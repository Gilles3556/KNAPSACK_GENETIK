package pndgV5.start;


import pndgV5.model.MesOutils;
import pndgV5.model.exceptions.GenerationException;
import pndgV5.model.exceptions.ResultatsException;
import pndgV5.model.genetik.*;

import java.util.Objects;
import java.util.Scanner;

class LanceurCombinaison {

    public static Scanner scan;

    public static void main( String[] args ) {
        LesResultats lesRes = new LesResultats();

        long startTime = System.currentTimeMillis();

        //POPULATION
        Population popDepart = OutilsGenetique2.creerPopulation();
        System.out.println("Population départ:" + popDepart.size());
        System.out.println("POIDS MAX=" + C2.POIDS_MAX);

        //Generation
        int nbSai = MesOutils.saisirEntier("Saisir nb d'éléments [5 à 26]?",5,26);

        System.out.println("/!\\ nb combinaisons: 2^"+nbSai+ " = "+(int)Math.pow(2,nbSai));

        MesOutils.saisirEntree();;

        Generation gen0 = null;
        Generation genNew2 = null;
        int e = 1;

        try {
            gen0 = OutilsGenetique2.creerGenerationDepart(nbSai, String.format("GEN0-%03d", e), popDepart);
            //OutilsGenetique2.afficherGeneration(popDepart,gen0,false);

            long endTime = System.currentTimeMillis();
            System.out.println("\nGEN0:  nb individu=" + gen0.size());

            System.out.println(OutilsGenetique2.calculerStrDureeTrt(startTime, endTime));
            OutilsGenetique2.afficherResultatsMutation(gen0);

            //----------------------------------------------------MUTATIONS
            Individu indivMax = gen0.getIndividuMaxValeur();
            lesRes.addResultat(new ResultatGeneration2(startTime, endTime, nbSai, gen0));

            Generation genNew3 = null;
            Generation genNew4 = null;

            //--Mut from MAX
            genNew2 = OutilsGenetique2.trt_mutation_fromMax(popDepart, indivMax);
            genNew2.setNom(String.format("GEN2-%03d", e));

            long endTime2 = System.currentTimeMillis();
            lesRes.addResultat(new ResultatGeneration2(startTime, endTime, nbSai, genNew2));

            OutilsGenetique2.afficherResultatsMutation(genNew2);
            System.out.println(OutilsGenetique2.calculerStrDureeTrt(startTime, endTime2));

            if (!genNew2.isVide()) {

                //un nombre pair d'élément est nécessaire
                if (genNew2.size() > 1) {
                    // mutation par paire (byMAX)
                    genNew3 = OutilsGenetique2.trt_mutation_paire(popDepart, genNew2, false);
                    if (genNew3.isVide()) {
                        // mutation par paire (byMINI)
                        genNew3 = OutilsGenetique2.trt_mutation_paire(popDepart, genNew2, true);
                    }
                    if (!Objects.isNull(genNew3))
                        genNew3.setNom(String.format("GEN3-%03d", e));
                    long endTime3 = System.currentTimeMillis();

                    //Afficher résultats mutations: PAIRE
                    OutilsGenetique2.afficherResultatsMutation(genNew3);
                    System.out.println(OutilsGenetique2.calculerStrDureeTrt(startTime, endTime3));
                }
                //
                if (!Objects.isNull(genNew3) && !Objects.isNull(genNew2)) {
                    if (genNew3.isVide()) {
                        genNew4 = OutilsGenetique2.trt_mutation_ajustement2(popDepart, genNew2, false);
                    } else {
                        genNew4 = OutilsGenetique2.trt_mutation_ajustement2(popDepart, genNew3, false);
                    }
                    if (!Objects.isNull(genNew4))
                        genNew4.setNom(String.format("GEN4-%03d", e));
                }
                long endTime4 = System.currentTimeMillis();
                lesRes.addResultat(new ResultatGeneration2(startTime, endTime4, nbSai, genNew4));

                //Afficher résultats mutations: AJUSTEMENT
                OutilsGenetique2.afficherResultatsMutation(genNew4);
                System.out.println(OutilsGenetique2.calculerStrDureeTrt(startTime, endTime4));
            }
            //------------QUESTION autre combinaisons que celle donnant IndividuMAX ???
            Individu maxi = lesRes.getIndividuMax();

            //--Recherche
            Generation lastGen = new Generation("GEN LAST", popDepart);
            lastGen.addIndividu(maxi);

            for (Individu ind : gen0.getLsIndividus()) {
                if (ind != maxi) {
                    if (ind.getValeur() >= maxi.getValeur() - 10) {
                        lastGen.addIndividu(ind);
                    }
                }
            }
            if (lastGen.size() > 0) {
                long endTime5 = System.currentTimeMillis();
                lesRes.addResultat(new ResultatGeneration2(startTime, endTime5, 0, lastGen));
            }


        } catch (ResultatsException rex) {
            //NOP
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        // ---------AFFICHAGES ----------------------------------
        OutilsGenetique2.afficherAllGenerationResultats(lesRes);
        OutilsGenetique2.afficherCompositionSac(popDepart, lesRes.getIndividuMax());

        System.out.println(OutilsGenetique2.afficherPopulationWithSac(popDepart, lesRes));

        OutilsGenetique2.afficherGeneration(popDepart,gen0,false);
        OutilsGenetique2.afficherGeneration(popDepart,genNew2,false);

    }



}
