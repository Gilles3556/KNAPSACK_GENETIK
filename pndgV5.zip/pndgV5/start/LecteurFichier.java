package pndgV5.start;


import pndgV5.model.genetik.OutilsGenetique2;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LecteurFichier {
    /**
     * Méthode chargée d'ajouter un séparateur entre chaque caractère.
     * @param strBinaire: String
     * @return
     */
    public static String ajouterSeparateur(String strBinaire){
        String strNew="";
        for(int i=0;i<strBinaire.length();i++){
            strNew+=strBinaire.charAt(i)+";";
        }
        return strNew;
    }
        /**
     * Méthode chargée de fournir la liste des combinaisons en lisant le fichier.
     * @param nomFichier:String
     * @return List<String>
     */
    public static List<String> lireCombinaisons( String nomFichier,int nbElement) throws Exception{
        List<String > liste = new ArrayList<String>();
        File file = new File(nomFichier);
        int max = (int) Math.pow(2,nbElement);

            FileReader fr = new FileReader(file.getAbsoluteFile());
            int i;
            int ctr=0;
            String str="";

            while((ctr<max) && (i=fr.read())!=-1){
                char c = (char)i;
                str+=c;

                if (c=='\n'){
                    System.out.print(" 2^"+str.length()+ " "+ajouterSeparateur(str));
                    liste.add(ajouterSeparateur(str));
                    str="";
                    ctr++;
                }

            }
            fr.close();

        return liste;

    }
    public static String completer(String strw, int nbElemen){
        while(strw.length()<nbElemen){
            strw+="0";
        }
        return strw;
    }
    public static List<int[]> lireCombinaisons2( String nomFichier,int nbElement) throws Exception{
        List<int[]> liste = new ArrayList<int[]>();
        int[] tablow;

        File file = new File(nomFichier);
        int max = (int) Math.pow(2,nbElement);

        FileReader fr = new FileReader(file.getAbsoluteFile());
        int i;
        int ctr=0;
        String str="";

        while((ctr<max) && (i=fr.read())!=-1){
            char c = (char)i;
            str+=c;

            if (c=='\n'){
                System.out.print(" 2^"+str.length()+ " "+ajouterSeparateur(str));

                if (str.length()<nbElement){
                    str=completer(str,nbElement);
                    ;                }
                //MEP tableaux
                tablow= new int[nbElement];

                str = ajouterSeparateur(str);
                str = str.replace("\n","");

                String[] tabStr = str.split(";");

                for(int z=0;z<tabStr.length;z++){
                    if(tabStr[z]!="\n") {
                        if(tabStr[z]!="")
                         tablow[z] = Integer.parseInt(tabStr[z]);
                    }
                }
                liste.add(tablow);
                str="";
                ctr++;
            }
        }
        fr.close();

        return liste;

    }
    // //////////////////////////////////////  PGM PRINCIPAL ////////////////////////////
    public static void main( String[] args ) {
        long tpsDebut= System.currentTimeMillis();

       //LECTURE DU FICHIER DES COMBINAISONS JQA 2^nb donné: (ici 10)
        try {
            //List<String > lsCombinaisons = lireCombinaisons("Combinaisons26.txt",10);
            List<int[] > lsCombinaisons = lireCombinaisons2("Combinaisons26.txt",14);

            long tpsFin2 = System.currentTimeMillis();
            System.out.println("nb combinaisons:"+lsCombinaisons.size());
            System.out.println(OutilsGenetique2.calculerStrDureeTrt(tpsDebut,tpsFin2));

           for(int i=0;i<lsCombinaisons.size();i++){
               int[] unTablo = lsCombinaisons.get(i);
               System.out.println(Arrays.toString(unTablo));
           }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
