package pndgV5.model;

import pndgV5.model.genetik.Objet;
import pndgV5.model.genetik.Valorisant;

import java.util.*;

public final class MesOutils {
    private MesOutils(){    }

    public static  String formaterNum3(int nb){
        return String.format("%03d",nb);
    }

    /**
     * Méthode chargée de faire saisir ENTREE.
     */
    public static void saisirEntree(){
        Scanner scan = new Scanner(System.in);
        System.out.println("[enter] pour continuer svp !");
        scan.nextLine();
    }

    /**
     * Méthode chargée de faire saisir un nombre ds [min:max].
     * @param msg String
     * @param min int
     * @param max max
     * @return int
     */
    public static int saisirEntier(String msg,int min ,int max){
        Scanner scan = new Scanner(System.in);
        int nbSai = 0;
        boolean ok = false;
        do {
            System.out.println(msg);
            nbSai = scan.nextInt();
            if (nbSai < min || nbSai > max) {
                System.out.println("saisie un nombre correct svp: ds ["+min+" à "+max+"]");
                ok = false;
            }else{
                ok=true;
            }
        } while (!ok);

        return nbSai;
    }

   /* public static int chercherMaximumPourUnPoids( List<Objet> lesObjets, Valorisant vobj0 ) {
        int poids0 = vobj0.getPoids();
        int val0 = vobj0.getValeur();

        int idxMax=-1;
        boolean max=false;
        int i=1;
        do{
           Valorisant vobj2 = (Valorisant) lesObjets.get(i);
           if (vobj2.getPoids()==poids0){
               if (vobj2.getValeur()>val0){
                   idxMax =i;
                   max=true;
               }
           }
        }while(!max && i<lesObjets.size());

        return idxMax;
    }*/

   /* public static Map<Integer, ArrayList> toMap( List<Objet> ls){
        Map<Integer,ArrayList> mapv= new HashMap<>() ;

        List<Integer> lsk= extraireClefPoids(ls);
        for (Integer intk:lsk) {
            List<Integer> lsv=extraireValeurClefPoids(intk,ls);
            mapv.put(intk, (ArrayList) lsv);
        }
        return mapv;
    }


    private static List<Integer> extraireValeurClefPoids(Integer intk,List<Objet> ls){
        List<Integer> lsv= new ArrayList<>();
        for (Object obj:ls ) {
            Valorisant vobj = (Valorisant) obj;
            if (vobj.getPoids()== intk.intValue()){
                lsv.add(vobj.getValeur());
                Collections.sort(lsv);
            }
        }
        return lsv;
    }
    private static List<Integer> extraireClefPoids(List<Objet> ls){
        List<Integer> lsk =new ArrayList<Integer>();

        for (Object obj: ls) {

            Valorisant vObj = (Valorisant) obj;
            int p = vObj.getPoids();
            int v = vObj.getValeur();
            Integer intPoids = Integer.valueOf(p);
            if (!lsk.contains(intPoids)) {
                lsk.add(Integer.valueOf(intPoids));
            }
        }
        return lsk;
    }*/
}
