package pndgV5.model.exceptions;

public class ObjetException extends Exception {
    public ObjetException( String msg ) {
        super(msg);
    }
}
