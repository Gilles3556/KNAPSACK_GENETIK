package pndgV5.model.exceptions;

public class GenerationException extends Exception {
    public GenerationException( String msgPasDePlace ) {
        super(msgPasDePlace);
    }
}
