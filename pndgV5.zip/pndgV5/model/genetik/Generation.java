package pndgV5.model.genetik;

import pndgV5.model.exceptions.GenerationException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Generation {
    private String nom;
    private List<Individu> lsIndividus;
    private Population pop;

    public Generation( String nom, Population pop ) {
        this.nom=nom;
        lsIndividus = new ArrayList<>();
        this.pop=pop;
    }

    public String getNom() {
        return nom;
    }

    public void setNom( String nom ) {
        this.nom = nom;
    }

    public List<Individu> getLsIndividus() {
        return lsIndividus;
    }

    public Generation( String nom){
        this.nom=nom;
        lsIndividus = new ArrayList<>();
    }

    public void setPop( Population pop ) {
        this.pop = pop;
    }

    /**
     * Méthode chargéed'ajouter un INDIVIDU dans le tableau.
     * @param unIndiv: Individu
     */
    public void addIndividu( Individu unIndiv) throws GenerationException {

        if (Objects.isNull(unIndiv)) {
            throw new GenerationException(C2.MSG_OBJET_VAUT_NULL);
        }

       if (lsIndividus.contains(unIndiv)) {
            throw new GenerationException(C2.MSG_OBJET_DEJA_PRESENT);
        }

        //Test du poids: generation
        int [] tab = this.calculerTotaux();
        int poidsGene = tab[C2.IDX_POIDS];

        if( poidsGene>= C2.POIDS_MAX){
            throw new GenerationException(C2.MSG_POIDS_MAX_ATTEINT);
        }
        //TEST du pois de l'individu
        int poidsIndiv = unIndiv.calculerPoids(pop);

        if((poidsGene+poidsIndiv)> C2.POIDS_MAX){
            throw new GenerationException(C2.MSG_POIDS_MAX_DEPASSE);
        }

        lsIndividus.add(unIndiv);
    }


    /**
     * Méthode chargée de calculer les totaux POIDS et VALEUR.
     * @return int[]: tableau des totaux 0=poids,1=valeur
     */
    public int[] calculerTotaux( ){
        int[] tab= new int[2];
        //Parcours des présences d'un Individu
        for(int z=0;z<lsIndividus.size();z++){
            tab[C2.IDX_VAL]=0;
            tab[C2.IDX_POIDS]=0;

            //TRT un individu
            Individu unIndividu = lsIndividus.get(z);

            for(int y=0;y<unIndividu.getTabPresences().length;y++) {
                if (unIndividu.getPresenceAt(y) == 1) {
                    Objet obj = pop.getLesObjets().get(y);

                    tab[C2.IDX_VAL] += obj.getValeur();
                    tab[C2.IDX_POIDS] += obj.getPoids();
                }
            }
        }
        return tab;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Generation{");
        sb.append("nom=").append(this.nom);
        sb.append(" nb individus: ").append(this.size());
        //sb.append(", tabIndividus=");
        for(int i=0;i<lsIndividus.size();i++){
           sb.append("\n - ");
           sb.append(lsIndividus.get(i));
        }
        sb.append('}');
        return sb.toString();
    }

    public boolean isVide(){
        return (lsIndividus.size()==0);
    }

    public int size(){
        return lsIndividus.size();
    }

    public Individu getIndividuMaxValeur(){
        Individu iMax=null;
        if(lsIndividus.size()!=0) {
            //Création du tableau des valeurs
            // et recherche du maxi (valeur)
            int maxi = 0;
            int idxMaxi = 0;
            int[] tabValeurs = new int[lsIndividus.size()];

            for (int i = 0; i < lsIndividus.size(); i++) {
                Individu un = lsIndividus.get(i);
                tabValeurs[i] = un.calculerValeur(pop);
                if (tabValeurs[i] > maxi) {
                    idxMaxi = i;
                    maxi = tabValeurs[i];
                }
            }
            iMax=lsIndividus.get(idxMaxi);
        }
        return iMax;
    }


    public int getMaxValeur(){
        return getIndividuMaxValeur().calculerValeur(pop);
    }

    public int getMinValeur(  ) {
        return getIndividuMinValeur().calculerValeur(pop);
    }

    public Individu getIndividuMinValeur( ) {
        //Création du tableau des valeurs
        // et recherche du maxi (valeur)
        int mini=100;
        int idxMini=0;
        int[] tabValeurs=new int[lsIndividus.size()];

        for(int i=0;i< lsIndividus.size();i++){
            Individu un= lsIndividus.get(i);
            tabValeurs[i]=un.calculerValeur(pop);
            if (tabValeurs[i]<mini){
                idxMini=i;
                mini=tabValeurs[i];
            }
        }

        return lsIndividus.get(idxMini);
    }
}
