package pndgV5.model.genetik;

import pndgV5.model.exceptions.ObjetException;

import java.util.Objects;
import java.util.UUID;

public class Objet implements Valorisant, Comparable{
    private UUID uuid;  //identifiant unique en Java
    private int valeur;
    private int poids;

    private void setValeur(int newV) throws ObjetException {
        if (newV<=0){
            throw  new ObjetException(C2.MSG_VALEUR_INCORRECTE);
        }
        this.valeur = newV;
    }
    private void setPoids(int newP) throws ObjetException {
        if (newP<=0){
            throw  new ObjetException(C2.MSG_POIDS_INCORRECT);
        }
        if(newP>= C2.POIDS_MAX){
            throw  new ObjetException(C2.MSG_POIDS_MAX);
        }
        this.poids = newP;
    }

    public Objet( int v, int p) throws ObjetException {
        uuid = UUID.randomUUID();
        setValeur(v);
        setPoids(p);
    }

    @Override
    public int getValeur() {
        return valeur;
    }

    @Override
    public int getPoids() {
        return poids;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Objet{");
        sb.append("uuid=").append(uuid);

        sb.append(", poids=").append(String.format("%03d",poids));
        sb.append(", valeur=").append(String.format("%03d",valeur));
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo( Object o ) {
        Objet obj = (Objet)o;
        int resultat;
        if (this.poids == obj.getPoids()){
            resultat =0;
        }
        if(this.poids> obj.getPoids()){
            resultat = 1;
        }else{
            resultat = -1;
        }

        return resultat;
    }

    @Override
    public boolean equals( Object o ) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Objet objet = (Objet) o;
        return valeur == objet.valeur && poids == objet.poids && uuid.equals(objet.uuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uuid, valeur, poids);
    }



    public Objet clone() throws CloneNotSupportedException {
        Objet objNew = null;
        try {
            objNew = new Objet(this.valeur,this.poids);
        } catch (ObjetException e) {
            throw new CloneNotSupportedException(e.getMessage());
        }
        return objNew;

    }
}
