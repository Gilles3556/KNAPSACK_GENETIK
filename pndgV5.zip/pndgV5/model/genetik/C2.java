package pndgV5.model.genetik;

public class C2 {
    public final static int POIDS_MAX=45; //25
    public final static int POIDS_SEUIL= POIDS_MAX/2;
    public static final int SEUIL = 12;

    public final static int[][] TABLO_DONNEES ={
            {9,10},{6,3},{3,1},{4,1},{9,6},
            {10,1},{8,2},{2,7},{7,1},{4,7},
            {2,4},{5,5},{10,5},{2,3},{10,7},
            {9,1},{1,8},{4,5},{8,1},{4,4},
            {1,5},{10,1},{1,2},{8,4},{9,5},
            {1,6},{10,1},{1,3},{8,4},{9,6},//AJOUT 1
            {3,5},{10,2},{3,2},{4,8},{1,5}, //AJOUT 2
            {2,1},{7,5},{10,5},{9,3},{10,1} //AJOUT 3


    };
    public static final String NOM_FICHIER_COMBINAISONS = "Combinaisons26.txt";

    public static final String MSG_VALEUR_INCORRECTE = "ERREUR: valeur interdite(<=0)";
    public static final String MSG_POIDS_INCORRECT = "ERREUR: poids interdit(<=0 ou >MAX)";
    public static final String MSG_POIDS_MAX = "ERREUR: poids interdit(>MAX)";
    public static final String MSG_OBJET_VAUT_NULL = "ERREUR: l'objet vaut NULL";
    public static final String MSG_OBJET_DEJA_PRESENT = "ERREUR: l'objet est déjà présent dans la liste";
    public static final String MSG_POIDS_MAX_ATTEINT = "ERREUR: poids MAX déja atteint";
    public static final String MSG_POIDS_MAX_DEPASSE = "ERREUR: Poids maximum autorisé dépassé !";

    public static final int IDX_VAL = 1;
    public static final int IDX_POIDS = 0;

    public static final int MAX_NB_GEN = 26; // Nombre max pour les générations soit 2^26
}
