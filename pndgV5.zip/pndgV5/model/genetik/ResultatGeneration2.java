package pndgV5.model.genetik;

import java.util.Arrays;
import java.util.Objects;

public class ResultatGeneration2 {
    public final static String ENTETES="| Nom Génération       |nb.obj GEN || nb obj |  P  |  V  |  Durées des traitements| Objets Présents";
    public final static String LIGNE  ="| ---------------------|-----------||--------|-----|-----|------------------------|-----------------------------";
    public final static String GEN_VIDE=                         "| ";
    public final static String GEN_NULL=                      "|           ||        |     |     |                        |";

    private long debut;
    private long fin;
    private int dmd;
    private Generation uneGeneration;

    public Generation getUneGeneration() {
        return uneGeneration;
    }

    public ResultatGeneration2( long debut, long fin, int dmd, Generation gene ) {
        this.debut = debut;
        this.fin = fin;
        this.dmd = dmd;
        this.uneGeneration = gene;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("| ");
        if (Objects.isNull(uneGeneration)) {
            sb.append(" Génération vaut NULL");
            sb.append(GEN_NULL);
        } else {
            sb.append(String.format("%20s", uneGeneration.getNom())).append(" | ");
            sb.append(String.format("...%03d   ", dmd)).append(" |");

            if (uneGeneration.isVide()) {
                sb.append("|génération est vide!");
                sb.append(GEN_VIDE);
            } else {
                Individu ind = uneGeneration.getIndividuMaxValeur();
                sb.append("|").append(String.format("  %03d  ", ind.calculerPresence())).append(" | ");

                sb.append(String.format("%03d", ind.getPoids())).append(" | ");
                sb.append(String.format("%03d", ind.getValeur())).append(" | ");

                sb.append(String.format("%20s ",OutilsGenetique2.calculerStrDureeTrt(debut, fin))).append(" |.");
                 int[] tabP = ind.getTabPresences();
                sb.append(Arrays.toString(tabP));
            }

        }
        return sb.toString();
    }

    @Override
    public boolean equals( Object o ) {

        /* if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ResultatGeneration2 that = (ResultatGeneration2) o;
        return dmd == that.dmd && Objects.equals(uneGeneration, that.uneGeneration);*/

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ResultatGeneration2 rg2 =(ResultatGeneration2)o;
        if(Objects.isNull(rg2.uneGeneration)|| Objects.isNull(uneGeneration))
            return false;

        Individu indMax0 = rg2.uneGeneration.getIndividuMaxValeur();
        Individu indMaxThis = uneGeneration.getIndividuMaxValeur();
        if(Objects.isNull(indMax0)|| (Objects.isNull(indMaxThis))){
            return false;
        }
        return (indMax0.getPoids() == indMaxThis.getPoids() && indMax0.getValeur()== indMaxThis.getValeur());
    }

    @Override
    public int hashCode() {
        return Objects.hash( uneGeneration.getIndividuMaxValeur());
    }
}
