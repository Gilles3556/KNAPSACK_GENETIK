package pndgV5.model.genetik;


public interface Valorisant {

    public int getValeur();
    public int getPoids();

    public int compareTo( Object o );
    public Objet clone() throws CloneNotSupportedException;
}
