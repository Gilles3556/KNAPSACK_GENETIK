package pndgV5.model.genetik;



import pndgV5.model.exceptions.GenerationException;

import java.util.Arrays;
import java.util.Random;

public class Individu {
    private int[] tabPresences;
    private int poids;
    private int valeur;

    public Individu(int dim){
        tabPresences = new int[dim];
    }
    public Individu(int[] tabP){
        this.tabPresences = tabP;
    }

    public Individu(boolean[] tabP){
        tabPresences = new int[tabP.length];
        for(int i=0;i<tabP.length;i++){
                tabPresences[i] = (tabP[i]?1:0);
        }
    }

    public int[] getTabPresences() {
        return tabPresences;
    }

    public void setPoids( int poids ) {
        this.poids = poids;
    }

    public void setValeur( int valeur ) {
        this.valeur = valeur;
    }

    public int getPoids() {
        return poids;
    }

    public int getValeur() {
        return valeur;
    }


    public void generer(int deb){
        //Génération du tableau des P
        Random rd = new Random();
        //int max = rd.nextInt(this.tabPresences.length)+2;
        int ctr=0;
        for(int i=0;i<deb;i++){
            int p=rd.nextInt(2);
            tabPresences[i] = p;
        }
        //Calcul du poids
    }

    public int getPresenceAt(int idx){
        return tabPresences[idx];
    }

    public int calculerPoids( Population pop){
        int totalPoids=0;
        for(int y=0;y<this.getTabPresences().length;y++) {

            if (this.getPresenceAt(y) == 1) {
                if(y<pop.size()) {
                    Objet obj = pop.getLesObjets().get(y);
                    if (obj != null)
                        totalPoids += obj.getPoids();
                }
            }
        }
        this.poids = totalPoids;
        return totalPoids;
    }
    public int calculerValeur( Population pop){
        int totalV=0;
        for(int y=0;y<this.getTabPresences().length;y++) {
            if (this.getPresenceAt(y) == 1) {
                if(y<pop.size()) {
                    Objet obj = pop.getLesObjets().get(y);
                    if (obj != null)
                        totalV += obj.getValeur();
                }
            }
        }
        this.valeur = totalV;
        return totalV;
    }

    public int calculerPresence(){
        int totalPresence=0;
        for(int i=0;i<tabPresences.length;i++){
            if (tabPresences[i]==1){
                totalPresence ++;
            }
        }
        return totalPresence;
    }
    public int calculerAbsence(){
        return tabPresences.length-calculerPresence();
    }

    public boolean isPoidsCorrect( Population pop){
        int lePoids = this.calculerPoids( pop);
        return (lePoids>= C2.SEUIL && lePoids<= C2.POIDS_MAX);
    }

    public boolean isValeurSupEgale( Population pop, int max){
        int valeur = this.calculerValeur(pop);
        return (valeur >= max);
    }

    public String toString( Population pop, boolean withP){
        final StringBuffer sb = new StringBuffer("Individu{");
        //sb.append("@");
        sb.append(String.format("@ %10d",super.hashCode()));
        sb.append("_ ");
        if(withP) {
            sb.append("PRESENCES=");
            if (tabPresences == null) sb.append("null");
            else {
                sb.append('[');
                for (int i = 0; i < tabPresences.length; ++i) {
                    sb.append(i == 0 ? "" : ", ").append(tabPresences[i]);
                }
                sb.append(']');
                sb.append("\n nb objet= " + this.calculerPresence());
            }
        }
        sb.append(" POIDS = ").append(this.calculerPoids(pop));
        sb.append(" VALEUR= ").append(this.calculerValeur(pop));

        sb.append('}');
        return sb.toString();
    }

    @Override
    public boolean equals( Object o ) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Individu individu = (Individu) o;
        return Arrays.equals(tabPresences, individu.tabPresences);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(tabPresences);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Individu{");
        sb.append("poids=").append(String.format("%03d",poids));
        sb.append(", valeur=").append(String.format("%03d",valeur));
        sb.append('}');
        return sb.toString();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
       Individu clone = new Individu(this.tabPresences.length);
       clone.setPoids(this.getPoids());
       clone.setValeur(this.getValeur());

       int[] tablo= new int[this.tabPresences.length];
       for(int i=0;i<tablo.length;i++){
           tablo[i] = this.tabPresences[i];
        }
       return clone;
    }
    public void setPresenceAt(int idx) throws GenerationException {
        if(idx<0 || idx>tabPresences.length){
            throw new GenerationException(("Indicd incoorcet pour maj Tableau des présences"));
        }
        tabPresences[idx]=1;

    }
}
