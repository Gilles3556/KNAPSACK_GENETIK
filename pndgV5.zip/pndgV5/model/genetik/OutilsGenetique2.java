package pndgV5.model.genetik;


import pndgV4.model.Valorisant;
import pndgV5.model.MesOutils;
import pndgV5.model.exceptions.GenerationException;

import java.io.*;
import java.util.*;

public final class OutilsGenetique2 {
    private OutilsGenetique2(){}

    public static Population creerPopulation( )  {
        return new Population();
    }

    /**
     * Méthode chargée de créer la première Génération
     * @param nbElements: int, le nombre d'éléments
     * @param nom: String
     * @param popDepart: Population de départ
     * @return Generation: laprmière génération
     * */
    public static Generation creerGenerationDepart(int nbElements, String nom, Population popDepart) throws Exception {
        long tps1=System.currentTimeMillis();
        Generation gen0= new Generation(nom,popDepart);

        List<int[]> listeCombinaisons=OutilsGenetique2.genererCombinaisons3(nbElements);

        //System.out.println("/!\\ Nb combinaisons:"+listeCombinaisons.size());

        //MEP des Individus à partir des combinaisons
        for(int i=0;i< listeCombinaisons.size();i++){
            Individu indiv= new Individu(listeCombinaisons.get(i));
            indiv.calculerPoids(popDepart);
            indiv.calculerValeur(popDepart);

            try {
                gen0.addIndividu(indiv);
                //--
                System.out.print(".");
                if(gen0.size()%120==0){
                    System.out.println(" ! ");
                }
            } catch (GenerationException e) {
                //Individu ne pouvant être ajouté: POIDS< SEUIL ou POIDS>MAX
            }
        }
        long tps2=System.currentTimeMillis();

        System.out.println("\nfin generation DEPART: "+calculerStrDureeTrt(tps1,tps2));

        return gen0;
    }


    /**
     * Méthode chargée de renvoyer toutes les combinaison de t éléments.
     * @param t: dimension (les éléments à combiner)
     * @return boolean[][]: le résultat sous forme de tableau de booléens
     *
     *  CODE SCE: https://codes-sources.commentcamarche.net/source/29425-combinaisons
     *
     */
    public static boolean[][] genererCombinaisons(int t ){
        boolean[][]comb=new boolean[(int)Math.pow(2,t)][t];
        for(int i=0;i<comb.length;i++){
            int a=i;
            for(int j=comb[0].length-1;j>=0;j--){
                if(a%2==1){
                    comb[i][j]=true;
                    a=(int)(a/2);
                }
                else{
                    a/=2;
                }
            }
        }
        return comb;
    }
    public static List<int[]> genererCombinaisons2(int t ){
       List<int[]> listeCombinaisons = new ArrayList<>();

        for(int nb=0;nb<t;nb++){
            int a=nb;
            System.out.println(">>trtr nombre ="+nb );

            int[] tablo = new int[64];

            for(int j=0;j<tablo.length;j++){
                if(a%2==1){
                    tablo[j]=1;
                }else{
                    tablo[j]=0;
                }
                a/=2;
            }
            listeCombinaisons.add(tablo);
            System.out.println(Arrays.toString(tablo));
        }

        return listeCombinaisons;
    }

    /**
     * Méthode chargée de lire le fichier des combinaisons (MAX 20).
     * @param t: nb élément à combiner
     * @return List<int[]>
     * @throws Exception
     */
    public static List<int[]> genererCombinaisons3(int t ) throws Exception {
        List<int[]> listeCombinaisons =  OutilsGenetique2.lireCombinaisons2(C2.NOM_FICHIER_COMBINAISONS,t);
        return listeCombinaisons;
    }


    /**
     * Méthode chargée d'afficher le délai entre deux temps(ms).
     * @param debut: temps début
     * @param fin: temps fin
     * @return String au format " %02d mn %02d s et %03d ms"
     */
    public static String calculerStrDureeTrt(long debut,long fin){
        String str="";
        //CALCULS
        long diffTemps = (fin - debut);

        long ms = diffTemps % 1000;
        long s = (diffTemps / 1000) % 60;
        long mn = (diffTemps / 1000) / 60;

        str = String.format(" %02d mn %02d s et %03d ms", mn, s, ms);

        return str;
    }

   //------------MUTATIONS
    /**
     * Méthode chargée de créer une mutation par moitié.
     * @param individu0: Individu, celui qui possède la valeur max
     * @param individu1: Individu, un autre individu
     * @param debut: boolean, VRAI=> recopie le début, False, recopie la fin
     * @return Individu le nouvel individu après mutation
     */
    public static Individu muter2( Individu individu0, Individu individu1, boolean debut){
        Individu indivNew = null;
        //recopie du tableau des présence de l'individu0
        int[] tabw =new int[C2.TABLO_DONNEES.length];
        for(int i=0;i<tabw.length;i++){
            tabw[i]= individu0.getPresenceAt(i);
        }

        int idx1 = C2.TABLO_DONNEES.length/2;
        int idx2 = C2.TABLO_DONNEES.length;

        if (debut){
            //recopier de 0 à idx2 le contenu du tableau
            for(int y=0;y<idx2;y++){
                tabw[y]=individu1.getPresenceAt(y);
                indivNew = new Individu(tabw);
            }
        }else{
            //Recopier de idx2+1 à MAX le contenu du tableau
            for(int y = idx1+1; y< C2.TABLO_DONNEES.length; y++){
                tabw[y]=individu1.getPresenceAt(y);
                indivNew = new Individu(tabw);
            }
        }
        return indivNew;
    }

    /**
     * Méthode chargée de réaliser la mutation d'un individu.
     * @param individu0: Individu
     * @return int[]
     */
    public static Individu muter(Individu individu0){
        Random rd = new Random();

        //Recopie du tableau ds un nouveau tableau
        int[] tab0 = new int[individu0.getTabPresences().length];
        for(int i=0;i<tab0.length;i++){
            tab0[i] = individu0.getPresenceAt(i);
        }
        //Mutations
        int idx1 =-1;
        int idx2=-1;
        do{
            idx1 = rd.nextInt(tab0.length);
            idx2 = rd.nextInt(tab0.length);
        }while(idx1 == idx2);

        tab0[idx1]=(tab0[idx1]==1?0:1);
        tab0[idx2]=(tab0[idx2]==1?0:1);

        Individu nouvIndiv = new Individu(tab0);
        return nouvIndiv;
    }

    /**
     * Méthode chargée de réaliser la mutration n°2: à partie de l'individu MAX (à valeur maxi)
     * @param pop
     * @param indivRef
     * @return
     */
    public static Generation trt_mutation_fromMax( Population pop, Individu indivRef ) {
        Generation gen2 = new Generation("GEN_M001",pop);

        int ctrMutation = 0;
        boolean sortir = false;
        do {
            //réaliser 2 mutations par bcle
            Individu nouvIndiv = OutilsGenetique2.muter(indivRef);

            // 1er critère le poids
            if (nouvIndiv.isPoidsCorrect(pop)) {

                //2eme critère la valeur MAX
                int valeur = nouvIndiv.calculerValeur(pop);
                int valeurRef = indivRef.calculerValeur(pop);

                if (nouvIndiv.isValeurSupEgale(pop, valeurRef)) {
                    try {
                        gen2.addIndividu(nouvIndiv);
                    } catch (GenerationException e) {
                    }
                }
            }
            //MEP d'un ctr pour éviter bcle infinie
            ctrMutation++;
            //afficherProgressionMutation(ctrMutation);

            sortir = (ctrMutation >= (C2.TABLO_DONNEES.length * C2.TABLO_DONNEES.length) && gen2.size() > 0 && gen2.size() < 20);
            if (ctrMutation > 1000000) {
                sortir = true;
            }
        } while (!sortir);

        return gen2;
    }

    /**
     * Méthode chargée d'ajuster(dernière mutation).
     * @param pop: Population
     * @param gene0: Generation , la génération à étudier
     * @param all: boolean, TRUE=examine la génération entière, FALSE=examine l'individu MAX
     * @return Generation
     */
    public static Generation trt_mutation_ajustement2( Population pop, Generation gene0, boolean all) {
        Generation gene = new Generation("GEN_M_AJUSTEMENT",pop);
        try{
            if(!all) { //Trt uniquement sur l'individu MAX
                Individu individuMaxGen3 = gene0.getIndividuMaxValeur();
                if (traiter_mut3_individu(pop,individuMaxGen3)){
                    gene.addIndividu(individuMaxGen3);
                }
            }else{
                //Traitement sur tous les individus de la génération précédente
                for(int i=0;i< gene0.size();i++){
                    Individu indivTrt = gene0.getLsIndividus().get(i);
                    if(indivTrt.calculerPoids(pop)<= C2.POIDS_MAX) {
                        //Trt chaque individu
                        if (traiter_mut3_individu(pop,indivTrt)){
                            if(indivTrt.calculerPoids(pop)<= C2.POIDS_MAX) {
                                gene.addIndividu(indivTrt);
                            }
                        }
                    }
                }
            }
        } catch (GenerationException e) {
        }

        //      System.out.println("\t========= trt_mutation_ajustement()  : "+gene.size());

        return gene;
    }
    private static boolean traiter_mut3_individu( Population pop, Individu indiv){
        int poids = indiv.calculerPoids(pop);
        int difference = C2.POIDS_MAX - poids;

        boolean mute=false;
        if (difference>=1) {
            //Parcours des gènes
            int[] tab = indiv.getTabPresences();
            for (int i = 0; i < tab.length; i++) {
                if (tab[i] == 0) { //gène non pris
                    pndgV4.model.Valorisant obj = (Valorisant) pop.getLesObjets().get(i);

                    if (obj.getPoids() <= difference) {
                        if ((poids + obj.getPoids()) <= C2.POIDS_MAX) {
                            //MAJ du gène de l'individu
                            tab[i] = 1;
                            mute = true;
                        }
                    }
                }
            }
        }
        return mute;
    }

    /**
     * Méthode chargée de crééer les mutation n°3: soit à partir du mini ou maxi
     * @param pop: Population
     * @param genNew2: Generation la génération précédente
     * @param byMini: boolean, indique si l'individu reference est le mini, sinon c'est le maxi
     * @return Generation
     */
    public static Generation trt_mutation_paire( Population pop, Generation genNew2, boolean byMini) {
        Generation gen3 = new Generation("GEN_M002",pop);

        //prendre l'individu max et le combiner avec les autres
        Individu indivRef = null;
        if (byMini) {
            indivRef = genNew2.getIndividuMinValeur();
        }else{
            indivRef= genNew2.getIndividuMaxValeur();
        }
        int maxValeurIg2 = indivRef.calculerValeur(pop);

        //Création du tableau des individus
        Individu[] tabloIndiGen2 = new Individu[genNew2.size()];
        int idx2 = 0;
        tabloIndiGen2[idx2] = indivRef;
        for (Individu unIndiv : genNew2.getLsIndividus()) {
            if (!unIndiv.equals(indivRef)) {
                idx2++;
                tabloIndiGen2[idx2] = unIndiv;
            }
        }
        //MEP mutations par moitié
        int idx3 = 1;
        while (idx3 < tabloIndiGen2.length) {
            try {
                Individu indivMute21 = OutilsGenetique2.muter2(indivRef, tabloIndiGen2[idx3], true);

                if (indivMute21.calculerValeur(pop) >= maxValeurIg2) {
                    gen3.addIndividu(indivMute21);
                }

                Individu indivMute22 = OutilsGenetique2.muter2(indivRef, tabloIndiGen2[idx3], false);
                if (indivMute22.calculerValeur(pop) >= maxValeurIg2) {
                    gen3.addIndividu(indivMute22);

                }
            } catch (GenerationException e) {
            }
            //--
            idx3++;
        }

        //System.out.println("\t========= trt_mutation_paire()   : "+gen3.size());
        return gen3;
    }

 // /////////////////////////////////////DAO
    /**
     * Méthode chargée d'ajouter un séparateur entre chaque caractère.
     * @param strBinaire: String
     * @return
     */
    public static String ajouterSeparateur(String strBinaire){
        String strNew="";
        for(int i=0;i<strBinaire.length();i++){
            strNew+=strBinaire.charAt(i)+";";
        }
        return strNew;
    }
    /**
     * Méthode chargée de générer ds un fichier toutes les combinaisons[1 à Long.MAX_VALUE] càd 63.
     * @param nomFichier: string
     */
    public static void genererFichierCombinaisons(String nomFichier) throws IOException {
        File file = new File(nomFichier);

        // créer le fichier s'il n'existe pas
        //et le supprimer si il existe
        if (file.exists()){
            file.delete();
        }
        file.createNewFile();

        FileWriter fw = new FileWriter(file.getAbsoluteFile());

        BufferedWriter bw = new BufferedWriter(fw);
        long nb=0;
        int puiss=30;

        do{
            String strBinL2= Long.toBinaryString(nb);
            //while(strBinL2.length()<puiss){
            //    strBinL2+="0";
            //}
            nb++;
            String strNb = String.format("%,010d !",nb);
            String content= strBinL2; //ajouterSeparateur(strBinL2);
            bw.write(content+"\n");
            System.out.println(strNb+content+" ^2:"+content.length());

        }while(nb<Math.pow(2,puiss));  //2^20: 1.048.576 ! 2^25: 33.554.432 ! 2^26: 67.108.864  !  2^30: 1.073.741.824

        bw.close();
        fw.close();
    }

    /**
     * Méthode chargée de fournir la liste des combinaisons en lisant le fichier.
     * @param nomFichier:String
     * @return List<String>
     */
    public static List<String> lireCombinaisons( String nomFichier,int nbElement) throws Exception{
        List<String > liste = new ArrayList<String>();
        File file = new File(nomFichier);
        int max = (int) Math.pow(2,nbElement);

        FileReader fr = new FileReader(file.getAbsoluteFile());
        int i;
        int ctr=0;
        String str="";

        while((ctr<max) && (i=fr.read())!=-1){
            char c = (char)i;
            str+=c;

            if (c=='\n'){
                System.out.print(" 2^"+str.length()+ " "+ajouterSeparateur(str));
                liste.add(ajouterSeparateur(str));
                str="";
                ctr++;
            }

        }
        fr.close();

        return liste;

    }

    public static String completer(String strw, int nbElemen){
        while(strw.length()<nbElemen){
            strw+="0";
        }
        return strw;
    }

    /**
     * Méthode chargée de fournir la liste des combinaisons en lisant le fichier.
     * @param nomFichier:String
     * @param nbElement: int le nombre d'élément à traiter ce qui donnera 2^nb combinaisons
     * @return List<int[]>
     */
    public static List<int[]> lireCombinaisons2( String nomFichier,int nbElement) throws Exception{
        long tps1=System.currentTimeMillis();
        System.out.println(">> lireCombinaison2()");
        List<int[]> liste = new ArrayList<int[]>();
        int[] tablow;

        File file = new File(nomFichier);
        int max = (int) Math.pow(2,nbElement);

        FileReader fr = new FileReader(file.getAbsoluteFile());
        int i;
        int ctr=0;
        String str="";

        while((ctr<max) && (i=fr.read())!=-1){
            char c = (char)i;
            str+=c;

            if (c=='\n'){
                //System.out.print(" 2^"+str.length()+ " "+ajouterSeparateur(str));

                if (str.length()<nbElement){
                    str=completer(str,nbElement);
;                }
                //MEP tableaux
                tablow= new int[nbElement];

                str = ajouterSeparateur(str);
                str = str.replace("\n","");

                String[] tabStr = str.split(";");

                for(int z=0;z<tabStr.length;z++){
                    if(tabStr[z]!="\n") {
                        if(tabStr[z]!="")
                         tablow[z] = Integer.parseInt(tabStr[z]);
                    }
                }
                liste.add(tablow);
                str="";
                ctr++;
            }
        }
        fr.close();
        long tps2 = System.currentTimeMillis();
        System.out.println("fin lecture fichier: "+calculerStrDureeTrt(tps1,tps2));

        return liste;

    }

    // ////////////////////////AFFICHAGES

    public static String afficherPopulationWithSac( Population pop, LesResultats lesRes ){
        Individu lindividuMax= lesRes.getIndividuMax();
        int valeurM=lindividuMax.getValeur();

        final StringBuffer sb = new StringBuffer("Population{\n");
        List<ResultatGeneration2> les = lesRes.getLs();
        for(ResultatGeneration2 rg2: lesRes.getLs()) {
           Generation gen = rg2.getUneGeneration();
            for (int i = 0; i < gen.size(); i++) {

                Individu unIndiv = gen.getLsIndividus().get(i);
                if (unIndiv.getValeur()>(valeurM-2)) {
                    sb.append(String.format("%n-- SAC %02d", (i + 1)));
                    sb.append(afficherPopulationWithSac(pop, unIndiv));
                }

            }
            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }

    public static String afficherPopulationWithSac( Population pop, Individu imax ) {
        final StringBuffer sb = new StringBuffer("Population{\n");
        for (int i = 0; i < pop.getLesObjets().size(); i++) {
            Objet obj = pop.getLesObjets().get(i);
            if (obj != null) {
                sb.append("#").append(MesOutils.formaterNum3(i)).append(":");
                sb.append(" V=").append(MesOutils.formaterNum3(obj.getValeur()));
                sb.append(" P=").append(MesOutils.formaterNum3(obj.getPoids()));
                if (i < imax.getTabPresences().length && imax.getPresenceAt(i) == 1) {
                    sb.append(" X ");
                } else {
                    sb.append(" . ");
                }

                sb.append(" | ");
                if ((i > 0 && ((i + 1) % 5 == 0))) {
                    sb.append(System.lineSeparator());
                }
            }
        }
        sb.append("\n}");
       return sb.toString();

    }

    public static void afficherCompositionSac( Population popDepart, Individu individuMax ) {
        System.out.println("\nCONTENU DU SAC (optimisé):");
        int[] tabP = individuMax.getTabPresences();
        int totalPoids=0;
        int totalValeur=0;

        for (int i = 0; i < tabP.length; i++) {
            if (tabP[i] == 1) {
                Objet obj = popDepart.getLesObjets().get(i);
                totalPoids=totalPoids+obj.getPoids();
                totalValeur=totalValeur+obj.getValeur();
                System.out.println(obj);
            }
        }
        System.out.println("------------------------------------------------ =========  ==========");
        System.out.println(String.format("%52s  =%03d        =%03d"," ",totalPoids,totalValeur));
        System.out.println("-------");
    }

    public static void afficherAllGenerationResultats( LesResultats lesRes ) {
        System.out.println(ResultatGeneration2.ENTETES);
        System.out.println(ResultatGeneration2.LIGNE);

        for (ResultatGeneration2 rg2 : lesRes.getLs()) {
            System.out.println(rg2);
        }

        System.out.println(ResultatGeneration2.LIGNE);
    }

    public static void afficherResultatsMutation( Generation genMut ) {
        System.out.println("--");
        if (Objects.isNull(genMut)) {
            System.out.println("Génération est NULLE");
        } else {
            if (genMut.isVide()) {
                System.out.println(genMut.getNom() + " est VIDE");
            } else {
                System.out.println(genMut.getNom() + ", nb individu:" + genMut.size());
                Individu indivMax2 = genMut.getIndividuMaxValeur();
                System.out.println(genMut.getNom() + " INDIV_MAX=" + indivMax2);
            }
        }
    }

    public static void afficherGeneration(Population pop, Generation gene, boolean all){

        System.out.println("\nGENERATIONS");
        if (Objects.isNull(gene)) {
            System.out.println(">> la génération est NULLE");
        }else {
            if (gene.isVide()) {
                System.out.println(">> la génération " + gene.getNom() + " est vide !");
            }else{
                Individu individuMax= gene.getIndividuMaxValeur();
                System.out.println("\tContenu Generation :"+gene.getNom()+ (all?" (all)": "(seuil et valeur-5)"));
                for (Individu unIndiv: gene.getLsIndividus()) {

                    String strIndividu = unIndiv.toString();

                    if(!all) {
                        if(unIndiv==individuMax){
                           strIndividu+=" MAXI";
                        }
                        if (unIndiv.getPoids()>=10 && unIndiv.getPoids()<=C2.POIDS_MAX){
                            if (unIndiv.getValeur()>= individuMax.getValeur()-5 ) {
                                strIndividu+= " [V-5,VMAX]";
                            }
                            System.out.println(strIndividu);
                        }
                    }else{
                        System.out.println(strIndividu);
                    }
                }
            }
        }

    }
}
