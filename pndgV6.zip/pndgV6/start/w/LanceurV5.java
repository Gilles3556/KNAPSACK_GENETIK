package pndgV6.start.w;

import pndgV5.model.genetik.C2;
import pndgV5.model.genetik.Individu;
import pndgV5.model.genetik.OutilsGenetique2;
import pndgV5.model.genetik.Population;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;


public class LanceurV5 {

    public final static Scanner scan = new Scanner(System.in);

    // -=-=-=-=-=-=-=-=-=-=-=-=-=- PGM PRINCIPAL -=-=-=-==-=-
    public static void main( String[] args ) {

        //MEP variable gestion du temps
        long startTime = System.currentTimeMillis();
        long endTime = -1;

        int ctrGen = 0;

        //POPULATION DEPART
        Population popDepart = OutilsGenetique2.creerPopulation();
        System.out.println("\n=_=_=_=_=_=_=_= POPULATION GENEREE : " + popDepart.getLesObjets().size() + " =_=_=_=_=_=_=_=_=_=_=_=_=_=_=");

        //clonage de la population de départ
        Population popw = clonerPopulation(popDepart);

        // Generation systématique des individus
        List<Individu> ls = new ArrayList<Individu>();
        //pour chaque individu ds population:0 jqà Pop;size()
        //construire un Individu (mep les Présences ou absences)
        Individu parent = null;
        Individu nouvo = null;

        for (int idx = 0; idx < popw.size(); idx++) {
            //System.out.println("IDX=" + idx);
            parent = traiter(popDepart, popw, parent, ls, idx);
            idx++;

            for(int idx2=idx;idx2<popw.size();idx2++){
                parent =traiter(popDepart, popw, parent, ls, idx);
            }
            popw = clonerPopulation(popDepart);
        }

        //}

        //Afficher les individus générés
        System.out.println("====================Les individus générés");
        for (Individu indiv : ls) {
            System.out.println(indiv.toString(popDepart, true));
        }
    }

    private static Population clonerPopulation( Population pop0 ) {
        Population popNew = null;
        try {
            popNew = pop0.clone();
        } catch (CloneNotSupportedException e) {
        }
        return popNew;
    }

    private static Individu traiter( Population popDepart, Population popw, Individu parent, List<Individu> ls, int idx ) {
        Individu nouvo = null;
        try {
            if (Objects.isNull(parent)) {
                nouvo = new Individu(C2.TABLO_DONNEES.length);
            } else {
                nouvo = (Individu) parent.clone();
            }
            nouvo.setPresenceAt(idx);
            nouvo.calculerValeur(popDepart);
            nouvo.calculerPoids(popDepart);

            ls.add(nouvo);  //Maj de la liste

            //popw.removeObjectAt(idx); //ôter l'objet de la population de w (reduire)

            parent = (Individu) nouvo.clone();  //MAJ du parent pour la suite

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return parent;
    }


}
