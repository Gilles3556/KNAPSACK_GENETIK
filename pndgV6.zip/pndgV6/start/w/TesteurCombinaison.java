package pndgV6.start.w;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TesteurCombinaison {

    public final static int DIM=10;

    private static void afficherListe(int p,List<String> lsw){
        System.out.println("Profondeur:"+p);
        for(String str:lsw){
            System.out.println(str);
        }
        System.out.println("--------------");
    }

    /**
     * Méthode chargée de créer toutes les combinaisons pour une profondeur.
     * @param prof: int la profondeur à traiter
     * @param ls: List<String>
     * @return List<String>
     */
    public static List<String> traiter1aDim( int prof, List<String> ls){
        System.out.println("trt traiter1aDim(): "+prof);

        List<String> ls2 = new ArrayList<String>();

        for(int p=1;p<=DIM;p++) {
                String newStr = null;
                for (String str : ls) {
                    newStr = String.format("%s-%d", str, p);
                    if (compterProfondeur(p,newStr)==1) {
                        if(!existerDeja(newStr,ls2)) {
                            ls2.add(newStr);

                            System.out.print(newStr+" | ");
                            if(ls2.size()%100==0){
                                System.out.println("");
                            }
                        }
                    }
                }
        }
        Collections.sort(ls2);
        return ls2;

    }
    public static boolean existerDeja(String uneCombinaison, List<String > ls){
        return ls.contains(uneCombinaison);
    }
    public static int compterProfondeur(int prof,String str){
        int ctr=0;
        for(int i=0;i<str.length();i++){
            String str1=str.charAt(i)+"";
            if (str1.contains(""+prof)){
                ctr++;
            }
        }
        return ctr;
    }

    private static String calculerStrDureeTrt(long debut,long fin){
        String str="";
        //CALCULS
        long diffTemps = (fin - debut);

        long ms = diffTemps % 1000;
        long s = (diffTemps / 1000) % 60;
        long mn = (diffTemps / 1000) / 60;

        str = String.format(" soit %02d mn %02d s et %03d ms", mn, s, ms);

        return str;
    }
    public static void main( String[] args ) {
        long startTime = System.currentTimeMillis();
        List<String> lsCombinaisons = new ArrayList<String>();
        //init
        for(int i=1;i<=DIM;i++){
            lsCombinaisons.add(""+i);
        }
        //Trt des profondeurs
        for(int profondeur=1;profondeur<=DIM;profondeur++){
           lsCombinaisons.addAll(traiter1aDim(profondeur,lsCombinaisons));
        }
        afficherListe(DIM,lsCombinaisons);

        System.out.println("Combinaisons OK size()="+lsCombinaisons.size());
    }


}
