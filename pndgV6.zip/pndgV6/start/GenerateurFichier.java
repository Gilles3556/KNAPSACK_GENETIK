package pndgV6.start;


import pndgV5.model.genetik.C2;
import pndgV5.model.genetik.OutilsGenetique2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class GenerateurFichier {
    /**
     * Méthode chargée d'ajouter un séparateur entre chaque caractère.
     * @param strBinaire: String
     * @return
     */
    public static String ajouterSeparateur(String strBinaire){
        String strNew="";
        for(int i=0;i<strBinaire.length();i++){
            strNew+=strBinaire.charAt(i)+";";
        }
        return strNew;
    }
    /**
     * Méthode chargée de générer ds un fichier toutes les combinaisons[1 à Long.MAX_VALUE] càd 63.
     * @param nomFichier: string
     */
    public static void genererFichierCombinaisons(String nomFichier) throws IOException {
        File file = new File(nomFichier);

        // créer le fichier s'il n'existe pas
        //et le supprimer si il existe
        if (file.exists()){
            file.delete();
        }
        file.createNewFile();


        FileWriter fw = new FileWriter(file.getAbsoluteFile());

        BufferedWriter bw = new BufferedWriter(fw);
        long nb=0;
        int puiss= C2.MAX_NB_GEN;

        do{
            String strBinL2= Long.toBinaryString(nb);
            //while(strBinL2.length()<puiss){
            //    strBinL2+="0";
            //}
            nb++;
            String strNb = String.format("%,010d !",nb);
            String content= strBinL2; //ajouterSeparateur(strBinL2);
            bw.write(content+"\n");
            System.out.println(strNb+content+" ^2:"+content.length());

        }while(nb<Math.pow(2,puiss));  //2^20: 1.048.576 ! 2^25: 33.554.432 ! 2^26: 67.108.864  !  2^30: 1.073.741.824

        bw.close();
        fw.close();
    }

    public static void genererFichierCombinaisons(String nomFichier,int nbD,int nbF) throws IOException {
        File file = new File(nomFichier);

        // créer le fichier s'il n'existe pas
        //et le supprimer si il existe
        if (file.exists()){
            file.delete();
        }
        file.createNewFile();


        FileWriter fw = new FileWriter(file.getAbsoluteFile());

        BufferedWriter bw = new BufferedWriter(fw);
        long nb= (long) Math.pow(2,nbD+1);

        do{
            String strBinL2= Long.toBinaryString(nb);
            //while(strBinL2.length()<puiss){
            //    strBinL2+="0";
            //}
            //nb++;
            String strNb = String.format("%,010d !",nb);
            String content= strBinL2; //ajouterSeparateur(strBinL2);
            bw.write(content+"\n");
            System.out.println(strNb+content+" ^2:"+content.length());
            nb++;

            //2^20: 1.048.576 ! 2^25: 33.554.432 ! 2^26: 67.108.864  !  2^30: 1.073.741.824
        }while(nb<Math.pow(2,nbF));

        bw.close();
        fw.close();
    }

    public static String completer(String strw, int nbElemen){
        while(strw.length()<nbElemen){
            strw+="0";
        }
        return strw;
    }

    // //////////////////////////////////////  PGM PRINCIPAL ////////////////////////////
    public static void main( String[] args ) {

        //création du fichier des combinaisons
       long tpsDebut = System.currentTimeMillis();
       try {
           //genererFichierCombinaisons("CombinaisonsW.txt"); // génére les BINAIRES jqa 2^26
           genererFichierCombinaisons("CombinaisonsW.txt",25,27);
           long tpsFin = System.currentTimeMillis();

           System.out.println(OutilsGenetique2.calculerStrDureeTrt(tpsDebut,tpsFin));
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
