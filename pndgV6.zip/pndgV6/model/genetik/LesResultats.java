package pndgV6.model.genetik;

import pndgV6.model.exceptions.ResultatsException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LesResultats {
    private List<ResultatGeneration2> ls;

    public List<ResultatGeneration2> getLs() {
        return ls;
    }

    public LesResultats(  ) {
        this.ls = new ArrayList<ResultatGeneration2>();
    }
    public void addResultat( ResultatGeneration2 rg2) throws ResultatsException {
        if(Objects.isNull(rg2)){
            throw new ResultatsException(C2.MSG_OBJET_VAUT_NULL);
        }
        if(ls.size()>0){
            if (ls.contains(rg2)){
                throw new ResultatsException(C2.MSG_OBJET_DEJA_PRESENT) ;
            }
        }
        ls.add(rg2);
    }
    public Individu getIndividuMax(){
        Individu max=null;
        int maxi=0;

        for(int i=0;i<ls.size();i++){
            ResultatGeneration2 rg2 = ls.get(i);
            if (rg2!=null){
                Generation gene = rg2.getUneGeneration();
                if(!Objects.isNull(gene)) {
                    Individu imax = gene.getIndividuMaxValeur();
                    if (!Objects.isNull(imax)) {
                        if (imax.getValeur() > maxi) {
                            max = imax;
                        }
                    }
                }
            }
        }
        return max;
    }
}
