package pndgV6.model.genetik;

/**
 * Interface des objets à gérer.
 * @param <T>: type d'objet
 */
public interface Valorisant<T> {

    public int getValeur();
    public int getPoids();
    public String getNom();

    public int compareTo( T o );
    public T clone() throws CloneNotSupportedException;
}
