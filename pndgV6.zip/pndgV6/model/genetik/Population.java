package pndgV6.model.genetik;

import pndgV6.model.MesOutils;
import pndgV6.model.exceptions.ObjetException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Population {

    private List<Valorisant > lesObjets;
    private Random rd = new Random();

    public List<Valorisant> getLesObjets() {
        return lesObjets;
    }

    public Population() {
        lesObjets= new ArrayList<>();
        initialiser3();
    }

    /**
     * Méthode chargée  d'initialiser  les objets au hasard(random).
     */
   /* private void intialiser()  {
       for(int f = 0; f< Constantes.MAX_FOIS; f++){
           int v= rd.nextInt(10)+1;
           int p =rd.nextInt(10)+1;

           try {
               Objet obj = new Objet(v,p);
               lesObjets.add(obj);
           } catch (ObjetException e) {
           }

       }
    }*/
    /**
     * Méthode chargée  d'initialiser les objets .
     */
    private void intialiser2(){
        for(int i = 0; i< C2.TABLO_DONNEES.length; i++){
            int v= C2.TABLO_DONNEES[i][0];
            int p= C2.TABLO_DONNEES[i][1];
            Objet vobj = null;
            try {
                vobj = new Objet("obj"+i,v,p);
                lesObjets.add(vobj);
            } catch (ObjetException e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * Méthode chargée  d'initialiser et de trier les objets (sur poids).
     */
    private void initialiser3(){
        intialiser2();
        //tri de la liste

        // Méthode permettant de trier => compareTo() et equals()
        //Collections.sort(lesObjets);
    }

    @Override
    public String toString() {
       final StringBuffer sb = new StringBuffer("Population{\n");
       for(int i=0;i<lesObjets.size();i++){
           if (lesObjets.get(i)!=null) {
               sb.append("#").append(MesOutils.formaterNum3(i)).append(":");
               sb.append(" V=").append(MesOutils.formaterNum3(lesObjets.get(i).getValeur()));
               sb.append(" P=").append(MesOutils.formaterNum3(lesObjets.get(i).getPoids()));
               sb.append(" | ");
               if ((i > 0 && ((i + 1) % 5 == 0))) {
                   sb.append(System.lineSeparator());
               }
           }
       }
        sb.append("\n}");
        return sb.toString();
    }

    public void removeObjectAt( int idx ) {
        if(idx>=0 && idx<lesObjets.size()){
            lesObjets.remove(idx);
           // lesObjets.add(idx,null);
        }
    }

    @Override
    public Population clone() throws CloneNotSupportedException {
        Population pop2=new Population();
        pop2.getLesObjets().clear();

        for(int i=0;i<lesObjets.size();i++){
            Objet objClone = (Objet)lesObjets.get(i).clone();
            pop2.getLesObjets().add(i,objClone);
        }

        return pop2;
    }

    public int size(){
        return lesObjets.size();
    }
}
