package pndgV6.model.exceptions;

public class ResultatsException extends Exception {
    public ResultatsException( String msg ) {
        super(msg);
    }
}
