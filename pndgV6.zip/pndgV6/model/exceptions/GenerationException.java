package pndgV6.model.exceptions;

public class GenerationException extends Exception {
    public GenerationException( String msgPasDePlace ) {
        super(msgPasDePlace);
    }
}
